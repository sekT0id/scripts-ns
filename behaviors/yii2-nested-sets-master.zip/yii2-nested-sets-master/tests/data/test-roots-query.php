<?php

return array (
  0 => 
  array (
    'id' => 1,
    'lft' => 1,
    'rgt' => 44,
    'depth' => 0,
    'name' => 'Root',
  ),
);