$(function(){
	$('#files').tree({
//		expanded: 'li:first'
	});
});