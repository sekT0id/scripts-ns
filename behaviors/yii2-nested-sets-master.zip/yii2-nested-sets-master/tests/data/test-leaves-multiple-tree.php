<?php

return array (
  0 => 
  array (
    'id' => 33,
    'tree' => 23,
    'lft' => 18,
    'rgt' => 19,
    'depth' => 3,
    'name' => 'Node 2.1.1',
  ),
  1 => 
  array (
    'id' => 34,
    'tree' => 23,
    'lft' => 20,
    'rgt' => 21,
    'depth' => 3,
    'name' => 'Node 2.1.2',
  ),
  2 => 
  array (
    'id' => 36,
    'tree' => 23,
    'lft' => 24,
    'rgt' => 25,
    'depth' => 3,
    'name' => 'Node 2.2.1',
  ),
  3 => 
  array (
    'id' => 37,
    'tree' => 23,
    'lft' => 26,
    'rgt' => 27,
    'depth' => 3,
    'name' => 'Node 2.2.2',
  ),
);