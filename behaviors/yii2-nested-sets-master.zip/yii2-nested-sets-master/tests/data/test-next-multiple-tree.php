<?php

return array (
  0 => 
  array (
    'id' => 38,
    'tree' => 23,
    'lft' => 30,
    'rgt' => 43,
    'depth' => 1,
    'name' => 'Node 3',
  ),
);