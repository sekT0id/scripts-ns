<?php

/* @var $this \yii\web\View */
/* @var $content string */
/* @var $model app\models\GenerationForm */
/* @var $form ActiveForm */

use yii\helpers\Html;
use yii\bootstrap\Nav;
use yii\bootstrap\NavBar;
use yii\widgets\Breadcrumbs;
use app\assets\AppAsset;
use yii\bootstrap\ActiveForm;

AppAsset::register($this);
?>
<?php $this->beginPage() ?>
<!DOCTYPE html>
<html lang="<?= Yii::$app->language ?>">
<head>
    <meta charset="<?= Yii::$app->charset ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?= Html::csrfMetaTags() ?>
    <title><?= Html::encode($this->title) ?></title>
    <?php $this->head() ?>
	<?= Html::csrfMetaTags() ?>
</head>
<body>
<?php $this->beginBody() ?>
<header>
	<div id="header">
		<?= $this->render('_form');?>
 	</div>
</header>


<div id="content">
<section>
        <?= Breadcrumbs::widget([
            'links' => isset($this->params['breadcrumbs']) ? $this->params['breadcrumbs'] : [],
        ]) ?>
        <?= $content ?>
</section>
</div>
<?php $this->endBody() ?>
</body>
</html>
<?php $this->endPage() ?>