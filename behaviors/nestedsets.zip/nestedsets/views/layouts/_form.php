<?php

namespace app\controllers;

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use app\models\NestedsetsForm;

/* @var $this yii\web\View */
/* @var $model app\models\nestedsets */
/* @var $form yii\widgets\ActiveForm */

if(!isset($model)) $model = new NestedsetsForm;
?>
<?php
    $form = ActiveForm::begin([
		'id' => 'GenerateNestedsets',
		'action' => ['nestedsets/generate'],
	]);
?>

	<?= Html::activeTextInput($model, 'depth', ['class'=>'form-item req', 'value'=>20]) ?>
	<?= Html::submitButton('Генерировать дерево') ?>
    <?php ActiveForm::end(); ?>