<?php

use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Nestedsets';
$this->params['breadcrumbs'][] = $this->title;
?>
<ul id="files">
	<?=$tree;?>
</ul>