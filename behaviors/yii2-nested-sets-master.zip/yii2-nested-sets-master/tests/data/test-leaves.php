<?php

return array (
  0 => 
  array (
    'id' => 11,
    'lft' => 18,
    'rgt' => 19,
    'depth' => 3,
    'name' => 'Node 2.1.1',
  ),
  1 => 
  array (
    'id' => 12,
    'lft' => 20,
    'rgt' => 21,
    'depth' => 3,
    'name' => 'Node 2.1.2',
  ),
  2 => 
  array (
    'id' => 14,
    'lft' => 24,
    'rgt' => 25,
    'depth' => 3,
    'name' => 'Node 2.2.1',
  ),
  3 => 
  array (
    'id' => 15,
    'lft' => 26,
    'rgt' => 27,
    'depth' => 3,
    'name' => 'Node 2.2.2',
  ),
);