<?php

return array (
  0 => 
  array (
    'id' => 23,
    'tree' => 23,
    'lft' => 1,
    'rgt' => 44,
    'depth' => 0,
    'name' => 'Root 2',
  ),
  1 => 
  array (
    'id' => 31,
    'tree' => 23,
    'lft' => 16,
    'rgt' => 29,
    'depth' => 1,
    'name' => 'Node 2',
  ),
  2 => 
  array (
    'id' => 32,
    'tree' => 23,
    'lft' => 17,
    'rgt' => 22,
    'depth' => 2,
    'name' => 'Node 2.1',
  ),
);